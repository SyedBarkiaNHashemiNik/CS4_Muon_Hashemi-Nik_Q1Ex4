public class Judges {
  private String name;
  private String likes;
  private int age;

  public Judges(String a, String b, int c) {
    name = a;
    likes = b;
    age = c;
  }

  public String getName() {
    return name;
  }
  public String getLikes() {
    return likes;
  }
  public int getAge() {
    return age;
  }
  
}